import java.util.*;

public class AddingMachine {

	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);
		boolean justStarting = true;
		int total = 0;
		int subtotal = 0;
		int last_k = -1;
		int k;
		while (true) {
		    // TODO Your code here
			k = scanner.nextInt();
			if (k == 0){
				if (last_k == 0){
					System.out.println("total " + total);
					return;
				}
				System.out.println("subtotal " + subtotal);
				subtotal = 0;
			}else{
				total += k;
				subtotal += k;
			}
			last_k = k;
		}
	}

}
