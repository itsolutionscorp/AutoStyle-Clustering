import java.util.*;

public class AddingMachine {

	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);
		boolean justStarting = true;
		int total = 0;
		int subtotal = 0;
		int k;
		while (true) {
			k=scanner.nextInt();
			if (k!=0) {
				justStarting=true;
				subtotal=subtotal+k;
			} else if (k==0 && justStarting) {
				System.out.println ("subtotal "+subtotal);
				total=subtotal+total;
				subtotal=0;
				justStarting=false;
			} else {
				System.out.println ("total "+total);
				return;
			}
		}

	}
}

