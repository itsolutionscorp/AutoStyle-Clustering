public class ListNode {

    private Object myItem;
    private ListNode myNext;

    public ListNode(Object item, ListNode next) {
        myItem = item;
        myNext = next;
    }
    public ListNode(Object item) {
        this(item, null);
    }

    public Object item() {
        return myItem;
    }
    public ListNode next() {
        return myNext;
    }
    public Object get (int x){
    	int counter = 0;
    	ListNode nextNode = this;
    	while(counter < x){
    		if (nextNode.next() == null){
    	    	return 10;
    			//throw new IllegalArgumentException("");
    		}else {
    			nextNode = nextNode.next();
        		counter++;
    		}
    	}return nextNode.myItem;
    }

}

