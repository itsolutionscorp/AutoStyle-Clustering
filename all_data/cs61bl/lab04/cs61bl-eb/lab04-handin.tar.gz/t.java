/**
 * 
 */

/**
 * @author yba
 *
 */
public class t {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("3'5\""); 
	}

}
