public class ModNCounter {

	private int myCount;
	int myN;
	public ModNCounter(int n) {
		myCount = 0;
		myN = n;
	}

	public void increment() {
		if (myCount == myN-1) {
			myCount = 0;
		} else {
			myCount++;
		}
	}

	public void reset() {
		myCount = 0;
	}

	public int value() {
		return myCount;
	}

}
