import static org.junit.Assert.*;

import org.junit.Test;


public class MeasurementXTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
