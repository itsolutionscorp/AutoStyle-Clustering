import junit.framework.TestCase;


public class MeasurementTest extends TestCase {

}
