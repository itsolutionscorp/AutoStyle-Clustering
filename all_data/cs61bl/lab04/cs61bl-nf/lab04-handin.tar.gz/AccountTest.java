import junit.framework.TestCase;


public class AccountTest extends TestCase {

}
