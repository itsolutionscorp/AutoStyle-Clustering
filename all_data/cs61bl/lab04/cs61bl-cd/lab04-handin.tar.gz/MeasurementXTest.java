import junit.framework.TestCase;


public class MeasurementXTest extends TestCase {

}
