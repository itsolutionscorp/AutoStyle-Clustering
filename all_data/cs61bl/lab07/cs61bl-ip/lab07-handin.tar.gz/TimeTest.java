import junit.framework.TestCase;


public class TimeTest extends TestCase {
	
	public void testConstructor() {
	    String[] timeArgs = {null, "x", "x:", ":x", "x:y", "1:", ":30",
	        "4: 35", "55:00", "11:99", " 3:30", "00004:45", "4:007", "4:7",
	        "4 :09", "3:30", "11:55"};
	    Time[] correctTimes = {null, null, null, null, null, null, null,
	        null, null, null, null, null, null, null, null,
	        new Time (3, 30), new Time (11, 55)};
	    for (int k = 0; k < timeArgs.length; k++) {
	        Time t = null;
	    	try {
		    	t = new Time(timeArgs[k]);
	    	} catch (IllegalArgumentException e) {
	    		System.err.println(e.getMessage());
	    		assertEquals(correctTimes[k], null);
	    	} catch (NullPointerException e) {
	    		System.err.println(e.getMessage());
	    	}
	    	assertEquals(correctTimes[k], t);
	    }
	}
	

//	public void testTimeString() {
//		fail("Not yet implemented");
//	}
//
//	public void testTimeIntInt() {
//		fail("Not yet implemented");
//	}
//
//	public void testEqualsObject() {
//		fail("Not yet implemented");
//	}
//
//	public void testToString() {
//		fail("Not yet implemented");
//	}

}
