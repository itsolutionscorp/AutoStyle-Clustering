public class Date {
    
    private int myMonth;        // months range from 1 (January) through 12 (December)
    private int myDateInMonth;  // dates-in-month range from 1 through the number of days in the month
    private int myYear;         // years are between 1900 and 2100 (arbitrary decision)

    public Date (int month, int dateInMonth, int year) {
        myMonth = month;
        myDateInMonth = dateInMonth;
        myYear = year;
    }
    
    // Determine if the date information is internally consistent.
    public void isOK() {
        boolean leapDay;
        if (myYear % 4 != 0) {
            leapDay = false;
        } else if (myYear % 100 != 0) {
            leapDay = true;
        } else if (myYear % 400 != 0) {
            leapDay = false;
        } else {
            leapDay = true;
        }
        if (myMonth < 0 || myMonth > 12){
        	throw new IllegalStateException("Months range from 1 to 12.");
        }
        if (leapDay && myMonth == 2){
    		if (myDateInMonth > 29 || myDateInMonth < 0){
    			throw new IllegalStateException ("Days in February of a leap year should range from 1 - 29.");
    		}
    	}
    	else if (myMonth == 2 && !leapDay){
    		if (myDateInMonth > 28 || myDateInMonth < 0){
    			throw new IllegalStateException ("Days in February of a regular year should range from 1 - 28.");
    		}
    	}
    	else if (myMonth == 4 || myMonth == 6 || myMonth == 9 || myMonth == 11){
    		if (myDateInMonth > 30 || myDateInMonth < 0){
    			throw new IllegalStateException ("Days in April, June, September, and November should range from 1 - 30.");
    		}
    	}
    	else{
    		if (myDateInMonth > 31 || myDateInMonth < 0){
    			throw new IllegalStateException ("Days in January, March, May, July, August, October, and December should ranbe from 1 - 31.");
    		}
    	}
        if (myYear < 1900 || myYear > 2100){
        	throw new IllegalStateException ("Year is not between 1900 and 2100.");
        }
    }
}
