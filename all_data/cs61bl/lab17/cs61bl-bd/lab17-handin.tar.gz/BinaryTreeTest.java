import junit.framework.TestCase;


public class BinaryTreeTest extends TestCase {
	
	public void testKthLargest() {
		
	}
	
}
