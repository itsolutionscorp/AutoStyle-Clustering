import static org.junit.Assert.*;

import org.junit.Test;


public class GitLetHelperTest {

	@Test
	public void testInit() {
		
	}

}
