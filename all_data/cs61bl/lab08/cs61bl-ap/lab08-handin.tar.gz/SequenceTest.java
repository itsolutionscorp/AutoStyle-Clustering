import junit.framework.TestCase;


public class SequenceTest extends TestCase {
	
	Sequence<String> seq = new Sequence<String> (12);
	
	
	

}
