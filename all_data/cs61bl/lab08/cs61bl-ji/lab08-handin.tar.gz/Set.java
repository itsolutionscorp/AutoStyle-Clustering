import java.util.NoSuchElementException;

public class Set {

	// Represent a set of nonnegative ints from 0 to maxElement-1
	// for some initially specified maxElement. 
	
	// contains[k] is true if k is in the set, false if it isn't
	private boolean[] contains;
	
	//Keeps track of the biggest value allowed
	private int max;
	
	private int k;
	
	public int k() {
		return k; 
	}
	public void initIterator() {
		k = 0;
	}
	
	public boolean hasNext() {
		if (isEmpty()) {
			return false;
		} else if (k == max) {
			return false;
		}
		return true;
	}
	
	public int next() throws NoSuchElementException {
		if (!hasNext()) {
			throw new NoSuchElementException("No such element exists.");
		}
		while (k < max) {
			if (member(k)) {
				k++;
				return k - 1;
			}
			k++;
		}
		return k - 1;
	}
	
	// Initialize a set of ints from 0 to maxElement-1.
	public Set (int maxElement) {
		this.max = maxElement - 1;
		this.contains = new boolean[maxElement];
	}
	
	// precondition: 0 <= k < maxElement.
	// postcondition: k is in this set.
	public void insert (int k) {
		if (k < 0 || k > max) {
			return;
		}
		this.contains[k] = true;
	}
	
	// precondition: 0 <= k < maxElement.
	// postcondition: k is not in this set.
	public void remove (int k) {
		if (k < 0 || k > max) {
			return;
		}
		this.contains[k] = false;
	}
	
	// precondition: 0 <= k < maxElement
	// Return true if k is in this set, false otherwise.
	public boolean member (int k) {
		if (k < 0 || k > max) {
			return false;
		}
		if (this.contains[k]) {
			return true;
		}
		return false;
	}
	
	// Return true if this set is empty, false otherwise.
	public boolean isEmpty() {
		for (int i = 0; i < max; i++) {
			if (this.contains[i] == true) {
				return false;
			}
		}
		return true;
	}

}
