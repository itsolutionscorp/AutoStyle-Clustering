import java.util.*;

public class AddingMachine {

	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);
		boolean justStarting = true;
		int total = 0;
		int subtotal = 0;
		
		int temp = 1;
		
		while (true) {
		    // TODO Your code here
			int k;
			k = scanner.nextInt();
			
			if (k != 0)
			{
				subtotal = subtotal + k;
			}
			else if (k == 0)
			{
				if (temp == k)
				{
					System.out.println("total " + total);
					return;
				}
				
				System.out.println("subtotal " + subtotal);
				total = total + subtotal;
				subtotal = 0;
			}
			
			temp = k;
			
		}
	}

}
