import java.util.*;

public class AddingMachine {

	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);
		boolean justStarting = true;
		int total = 0;
		int subtotal = 0;
		int n=0;
		while (true) {
		    n = scanner.nextInt();
		    if(n==0){
		    	if(justStarting){
		    		System.out.println("subtotal "+subtotal);
		    		subtotal = 0;
		    		justStarting = false;
		    	}
		    	else{
		    		System.out.println("total "+total);
		    		return;
		    	}
		    }
		    if(n!=0){
		    	subtotal = subtotal + n;
		    	total = total + n;
		    	justStarting = true;
		    }
		}
		
	}

}
