
import java.util.*;

public class AddingMachine {

	public static void main (String[] args) {
		Scanner abc = new Scanner(System.in);
		boolean justStarting = true;
		int total = 0;
		int subtotal = 0;
		while (true) {
			int k;
			k = abc.nextInt();
		    if (justStarting && (k == 0)){
		    	System.out.println (total);	
		    }
		    else if (k == 0) {
		    	System.out.println (subtotal);
		    	subtotal = 0;
		    	justStarting = true;
		    }
		    else {
		    	subtotal = subtotal + k;
		    	total = total + k;
		    	justStarting = false;
		    }
			
		}
	}

}
