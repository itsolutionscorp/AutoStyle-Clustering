package lab02;

import java.util.*;

public class AddingMachine {

	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);
		boolean justStarting = true;
		int total = 0;
		int subtotal = 0;
		int value = scanner.nextInt();
		
		while (value != 0 || justStarting) {
		    // TODO Your code here
		    justStarting = false;
			subtotal = 0;
			
			while(value != 0) {
				subtotal = subtotal + value;
				total = total + value;
				value = scanner.nextInt();
				}

			System.out.println ("subtotal " + subtotal);
			value = scanner.nextInt();
			} 

		System.out.println ("total " + total);
			
			
		}
}