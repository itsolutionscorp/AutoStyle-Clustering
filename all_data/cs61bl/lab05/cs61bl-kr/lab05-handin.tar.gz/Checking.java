
public class Checking {
int[] k = {1,2,3,4,5};
System.out.print(k.length);






}
