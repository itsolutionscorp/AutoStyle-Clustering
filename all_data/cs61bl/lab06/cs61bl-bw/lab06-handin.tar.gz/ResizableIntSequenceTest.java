import junit.framework.TestCase;


public class ResizableIntSequenceTest extends TestCase {

}
