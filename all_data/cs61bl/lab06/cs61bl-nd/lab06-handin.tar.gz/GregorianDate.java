public class GregorianDate extends Date {

	public static int[] monthLengths = { 31, 28, 31, 30, 31, 30, 31, 31, 30,
			31, 30, 31 };

	public GregorianDate(int year, int month, int dayOfMonth) {
		super(year, month, dayOfMonth);
	}

	@Override
	public int dayOfYear() {
		int rtnValue = 0;
		for (int m = 0; m < month() - 1; m++) {
			rtnValue += monthLengths[m];
		}
		return rtnValue + dayOfMonth();
	}

	public Date nextDate(){
		int newdayOfYear = this.dayOfYear() + 1;
		int m = 1,d = 1, y = year();

		Date result = new GregorianDate(y, m, d);
		if (newdayOfYear == 366){
			y = year() + 1;
			result = new GregorianDate(y, m, d);
			return result;
		}
		
		for(int i=0; i < monthLengths.length; i++){
			if(newdayOfYear <= monthLengths[i]){
				result = new GregorianDate(y, m, newdayOfYear);
				return result;
			}
			else{
				newdayOfYear = newdayOfYear - monthLengths[i];
				m++;
			}
		}

		return result;
	}

}
