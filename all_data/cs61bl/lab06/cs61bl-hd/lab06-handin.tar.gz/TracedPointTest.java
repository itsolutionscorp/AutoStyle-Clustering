import static org.junit.Assert.*;

import org.junit.Test;


public class TracedPointTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
