
public @interface overide {

}
