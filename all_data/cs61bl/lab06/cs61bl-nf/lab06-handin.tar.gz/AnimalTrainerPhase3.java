public class AnimalTrainerPhase3 {

	public void methodX(Animal a){
		System.out.println("method called on static type Animal");
	}

	public void methodX(Dog d){
		System.out.println("method called on static type Dog");
	}

	public void methodX(Cat c){
		System.out.println("method called on static type Cat");
	}

	public void methodX(Tiger t){
		System.out.println("method called on static type Tiger");
	}

}
