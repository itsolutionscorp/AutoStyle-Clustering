public class AnimalTrainer {

	public void methodA(Animal a){
		System.out.println("Animal Parameter");
	}

	public void methodD(Dog d){
		System.out.println("Dog Parameter");
	}

	public void methodC(Cat c){
		System.out.println("Cat Parameter");
	}

	public void methodT(Tiger t){
		System.out.println("Tiger Parameter");
	}

}
