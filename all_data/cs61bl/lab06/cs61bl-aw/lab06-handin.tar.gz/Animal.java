public class Animal {

	// instance variables
	int animalVariable;
	
	public void method1() {
		System.out.println("Animal: method1");
	}

	public void method4() {
		System.out.println("Animal: method4");		
	}

	public void method5() {
		System.out.println("Animal: method5");
	}

	public void method6() {
		System.out.println("Animal: method6");
	}

}
