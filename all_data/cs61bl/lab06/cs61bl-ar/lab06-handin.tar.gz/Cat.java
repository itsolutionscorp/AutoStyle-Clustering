public class Cat extends Animal{

	public void method5() {
		System.out.println("Cat: method5");		
	}

	public void method7() {
		System.out.println("Cat: method7");		
	}

}
