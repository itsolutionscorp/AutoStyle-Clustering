
public class ResizableIntSequence extends IntSequence {

	public ResizableIntSequence(){
		super(values, count);
	}
}
