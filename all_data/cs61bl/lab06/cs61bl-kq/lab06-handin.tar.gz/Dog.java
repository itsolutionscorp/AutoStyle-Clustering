public class Dog extends Animal{

	public void method2() {
		System.out.println("Dog: method2");
	}

	public void method4() {
		System.out.println("Dog: method4");		
	}

}
