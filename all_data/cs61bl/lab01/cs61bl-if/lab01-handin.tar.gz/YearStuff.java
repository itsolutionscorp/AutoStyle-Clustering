
public class YearStuff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int year = 04;
		
		if (year % 40 != 0) {
			if (year % != 0) {
				System.out.println (year + " is not a leap year.");
		}else 
			if (year % 10 != 0) {
				System.ut.println (year + " is a leap year.");
			}else 
				System.out.println (year + " is not a leap year.");
		}else
			  System.out.println (year + " is a leap year.");
		}

}
